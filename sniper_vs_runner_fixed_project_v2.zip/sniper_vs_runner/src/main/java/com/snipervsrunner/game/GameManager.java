package com.snipervsrunner.game;

import com.snipervsrunner.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import java.util.UUID;

public final class GameManager {
    private static UUID sniperId;
    private static UUID runnerId;
    private static boolean running;
    private static boolean preparing;
    private static int preparationTicks;
    private static int gameTicks;
    private static int glowCycleTicks;
    private static int glowTicksLeft;
    private static boolean finishing;
    private static int syncCounter;

    private static final int PREPARATION_DURATION = 200;
    private static final int GAME_DURATION = 20 * 60 * 10;
    private static final int GLOW_INTERVAL = 20 * 30;
    private static final int GLOW_DURATION = 20 * 5;

    private GameManager() {}

    public static boolean assign(ServerPlayer player, PlayerClass playerClass) {
        if (playerClass == PlayerClass.SNIPER) {
            if (sniperId != null && !sniperId.equals(player.getUUID())) return false;
            if (player.getUUID().equals(runnerId)) return false;
            sniperId = player.getUUID();
        } else {
            if (runnerId != null && !runnerId.equals(player.getUUID())) return false;
            if (player.getUUID().equals(sniperId)) return false;
            runnerId = player.getUUID();
        }
        broadcast(player.getServer(), Component.literal(player.getGameProfile().getName()
                + " назначен: " + (playerClass == PlayerClass.SNIPER ? "Снайпер" : "Раннер"))
                .withStyle(ChatFormatting.GREEN));
        syncAll(player.getServer());
        return true;
    }

    public static void deleteClass(ServerPlayer player) {
        if (player.getUUID().equals(sniperId)) sniperId = null;
        if (player.getUUID().equals(runnerId)) runnerId = null;
        player.sendSystemMessage(Component.literal("Твой класс удалён.").withStyle(ChatFormatting.YELLOW));
        syncAll(player.getServer());
    }

    public static boolean start(MinecraftServer server) {
        if (running || sniperId == null || runnerId == null || sniperId.equals(runnerId)) return false;
        ServerPlayer sniper = server.getPlayerList().getPlayer(sniperId);
        ServerPlayer runner = server.getPlayerList().getPlayer(runnerId);
        if (sniper == null || runner == null) return false;

        running = true;
        preparing = true;
        finishing = false;
        preparationTicks = PREPARATION_DURATION;
        gameTicks = GAME_DURATION;
        glowCycleTicks = GLOW_INTERVAL;
        glowTicksLeft = 0;
        syncCounter = 0;

        sniper.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, PREPARATION_DURATION, 0, false, false));
        broadcast(server, Component.literal("Матч начинается! У раннера 10 секунд форы.")
                .withStyle(ChatFormatting.GOLD));
        syncAll(server);
        return true;
    }

    public static void stop(MinecraftServer server, String message) {
        if (!running && !preparing) return;
        running = false;
        preparing = false;
        finishing = false;
        ServerPlayer sniper = getSniper(server);
        ServerPlayer runner = getRunner(server);
        clearEffects(sniper);
        clearEffects(runner);
        broadcast(server, Component.literal(message).withStyle(ChatFormatting.RED));
        syncAll(server);
    }

    public static void tick(MinecraftServer server) {
        if (!running) return;

        ServerPlayer sniper = getSniper(server);
        ServerPlayer runner = getRunner(server);
        if (sniper == null || runner == null) {
            stop(server, "Матч остановлен: один из игроков вышел.");
            return;
        }

        if (containsRedWool(runner)) {
            finishRunnerWin(server);
            return;
        }

        if (preparing) {
            preparationTicks--;
            if (preparationTicks <= 0) {
                preparing = false;
                sniper.removeEffect(MobEffects.BLINDNESS);
                broadcast(server, Component.literal("Снайпер может стрелять! У вас 10 минут.")
                        .withStyle(ChatFormatting.RED));
            }
        } else {
            gameTicks--;
            glowCycleTicks--;
            if (glowTicksLeft > 0) {
                glowTicksLeft--;
                if (glowTicksLeft == 0) runner.removeEffect(MobEffects.GLOWING);
            }
            if (glowCycleTicks <= 0) {
                glowCycleTicks = GLOW_INTERVAL;
                glowTicksLeft = GLOW_DURATION;
                runner.addEffect(new MobEffectInstance(MobEffects.GLOWING, GLOW_DURATION, 0, false, false));
            }
            if (gameTicks <= 0) {
                finishSniperWin(server, "Время вышло! Победил снайпер.");
                return;
            }
        }

        syncCounter++;
        if (syncCounter >= 10) {
            syncCounter = 0;
            syncAll(server);
        }
    }

    public static void onLivingDeath(LivingDeathEvent event) {
        if (!running || finishing || !(event.getEntity() instanceof ServerPlayer dead)) return;
        if (dead.getUUID().equals(runnerId)) {
            MinecraftServer server = dead.getServer();
            if (server != null) finishSniperWin(server, "Раннер убит! Победил снайпер.");
        }
    }

    private static void finishRunnerWin(MinecraftServer server) {
        if (finishing) return;
        finishing = true;
        ServerPlayer sniper = getSniper(server);
        stop(server, "Раннер добрался до красной шерсти! Победил раннер.");
        if (sniper != null && sniper.isAlive()) sniper.kill();
    }

    private static void finishSniperWin(MinecraftServer server, String message) {
        if (finishing) return;
        finishing = true;
        stop(server, message);
    }

    private static boolean containsRedWool(ServerPlayer player) {
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(Items.RED_WOOL)) return true;
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (stack.is(Items.RED_WOOL)) return true;
        }
        return false;
    }

    private static void clearEffects(ServerPlayer player) {
        if (player == null) return;
        player.removeEffect(MobEffects.BLINDNESS);
        player.removeEffect(MobEffects.GLOWING);
    }

    private static ServerPlayer getSniper(MinecraftServer server) {
        return sniperId == null ? null : server.getPlayerList().getPlayer(sniperId);
    }

    private static ServerPlayer getRunner(MinecraftServer server) {
        return runnerId == null ? null : server.getPlayerList().getPlayer(runnerId);
    }

    private static void broadcast(MinecraftServer server, Component message) {
        server.getPlayerList().getPlayers().forEach(player -> player.sendSystemMessage(message));
    }

    private static void syncAll(MinecraftServer server) {
        String sniper = getSniper(server) == null ? "—" : getSniper(server).getGameProfile().getName();
        String runner = getRunner(server) == null ? "—" : getRunner(server).getGameProfile().getName();
        int mainSeconds = Math.max(0, gameTicks / 20);
        int prepSeconds = Math.max(0, (preparationTicks + 19) / 20);
        int glowSeconds = Math.max(0, glowCycleTicks / 20);
        boolean visible = sniperId != null || runnerId != null || running;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ModNetwork.sendHud(player, visible, sniper, runner, running, preparing,
                    preparing ? prepSeconds : mainSeconds, glowSeconds);
        }
    }
}
