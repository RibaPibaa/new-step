package com.snipervsrunner.game;

public enum PlayerClass {
    SNIPER,
    RUNNER
}
