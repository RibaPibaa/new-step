package com.snipervsrunner.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.arguments.EntityArgument;
import com.snipervsrunner.game.GameManager;
import com.snipervsrunner.game.PlayerClass;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;

public final class GameCommands {
    private GameCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("sniper")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(context -> assign(context.getSource(),
                                EntityArgument.getPlayer(context, "player"), PlayerClass.SNIPER))));

        dispatcher.register(Commands.literal("runner")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(context -> assign(context.getSource(),
                                EntityArgument.getPlayer(context, "player"), PlayerClass.RUNNER))));

        dispatcher.register(Commands.literal("classdelete")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(context -> {
                            ServerPlayer player = EntityArgument.getPlayer(context, "player");
                            GameManager.deleteClass(player);
                            return 1;
                        })));

        dispatcher.register(Commands.literal("startgame")
                .requires(source -> source.hasPermission(2))
                .executes(context -> {
                    boolean started = GameManager.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() ->
                            net.minecraft.network.chat.Component.literal(started
                                    ? "Матч запущен." : "Не удалось начать: назначь двух разных игроков и убедись, что они онлайн."),
                            false);
                    return started ? 1 : 0;
                }));

        dispatcher.register(Commands.literal("stopgame")
                .requires(source -> source.hasPermission(2))
                .executes(context -> {
                    GameManager.stop(context.getSource().getServer(), "Матч остановлен администратором.");
                    context.getSource().sendSuccess(() ->
                            net.minecraft.network.chat.Component.literal("Матч остановлен."), true);
                    return 1;
                }));
    }

    private static int assign(CommandSourceStack source, ServerPlayer player, PlayerClass playerClass) {
        boolean success = GameManager.assign(player, playerClass);
        source.sendSuccess(() -> net.minecraft.network.chat.Component.literal(
                success ? "Класс назначен." : "Этот класс уже занят или игрок назначен на другую роль."), false);
        return success ? 1 : 0;
    }
}
