package com.snipervsrunner.network;

import com.snipervsrunner.client.ClientHudData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class HudS2CPacket {
    private final boolean visible;
    private final String sniper;
    private final String runner;
    private final boolean running;
    private final boolean preparing;
    private final int timerSeconds;
    private final int glowSeconds;

    public HudS2CPacket(boolean visible, String sniper, String runner, boolean running,
                        boolean preparing, int timerSeconds, int glowSeconds) {
        this.visible = visible;
        this.sniper = sniper;
        this.runner = runner;
        this.running = running;
        this.preparing = preparing;
        this.timerSeconds = timerSeconds;
        this.glowSeconds = glowSeconds;
    }

    public static void encode(HudS2CPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBoolean(packet.visible);
        buffer.writeUtf(packet.sniper);
        buffer.writeUtf(packet.runner);
        buffer.writeBoolean(packet.running);
        buffer.writeBoolean(packet.preparing);
        buffer.writeInt(packet.timerSeconds);
        buffer.writeInt(packet.glowSeconds);
    }

    public static HudS2CPacket decode(FriendlyByteBuf buffer) {
        return new HudS2CPacket(buffer.readBoolean(), buffer.readUtf(), buffer.readUtf(),
                buffer.readBoolean(), buffer.readBoolean(), buffer.readInt(), buffer.readInt());
    }

    public static void handle(HudS2CPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientHudData.update(packet.visible, packet.sniper, packet.runner, packet.running,
                        packet.preparing, packet.timerSeconds, packet.glowSeconds)));
        context.setPacketHandled(true);
    }
}
