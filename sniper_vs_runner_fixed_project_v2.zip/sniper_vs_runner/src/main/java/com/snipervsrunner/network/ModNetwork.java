package com.snipervsrunner.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation("snipervsrunner", "main"),
            () -> VERSION, VERSION::equals, VERSION::equals
    );

    private static boolean registered;

    private ModNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.messageBuilder(HudS2CPacket.class, 0)
                .encoder(HudS2CPacket::encode)
                .decoder(HudS2CPacket::decode)
                .consumerMainThread(HudS2CPacket::handle)
                .add();
    }

    public static void sendHud(ServerPlayer player, boolean visible, String sniper, String runner,
                               boolean running, boolean preparing, int timerSeconds, int glowSeconds) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new HudS2CPacket(visible, sniper, runner, running, preparing, timerSeconds, glowSeconds));
    }
}
