package com.snipervsrunner;

import com.snipervsrunner.command.GameCommands;
import com.snipervsrunner.game.GameManager;
import com.snipervsrunner.network.ModNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(SniperVsRunnerMod.MOD_ID)
public class SniperVsRunnerMod {
    public static final String MOD_ID = "snipervsrunner";

    public SniperVsRunnerMod() {
        ModNetwork.register();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        GameCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            GameManager.tick(event.getServer());
        }
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        GameManager.onLivingDeath(event);
    }
}
