package com.snipervsrunner.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber(modid = "snipervsrunner", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.FORGE)
public final class HudOverlay {
    private HudOverlay() {}

    @SubscribeEvent
    public static void onRender(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        if (!ClientHudData.visible) return;

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int width = minecraft.getWindow().getGuiScaledWidth();
        int x = width - 164;
        int y = 8;

        graphics.fill(x - 6, y - 5, width - 6, y + 66, 0xAA101010);
        graphics.drawString(minecraft.font, "SNIPER VS RUNNER", x, y,
                ChatFormatting.GOLD.getColor(), false);
        graphics.drawString(minecraft.font, "Снайпер: " + ClientHudData.sniper, x, y + 13,
                0xFFFFFF, false);
        graphics.drawString(minecraft.font, "Раннер: " + ClientHudData.runner, x, y + 25,
                0xFFFFFF, false);

        String state = !ClientHudData.running ? "Ожидание игроков"
                : ClientHudData.preparing ? "Фора: " + ClientHudData.timerSeconds + "с"
                : "Время: " + formatTime(ClientHudData.timerSeconds);
        graphics.drawString(minecraft.font, state, x, y + 39, 0x55FFFF, false);

        if (ClientHudData.running && !ClientHudData.preparing) {
            graphics.drawString(minecraft.font, "Подсветка через: " + ClientHudData.glowSeconds + "с",
                    x, y + 52, 0xFFFF55, false);
        }
    }

    private static String formatTime(int seconds) {
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }
}
