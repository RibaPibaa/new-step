package com.snipervsrunner.client;

public final class ClientHudData {
    public static boolean visible;
    public static String sniper = "—";
    public static String runner = "—";
    public static boolean running;
    public static boolean preparing;
    public static int timerSeconds;
    public static int glowSeconds;

    private ClientHudData() {}

    public static void update(boolean newVisible, String newSniper, String newRunner,
                              boolean newRunning, boolean newPreparing, int newTimerSeconds,
                              int newGlowSeconds) {
        visible = newVisible;
        sniper = newSniper;
        runner = newRunner;
        running = newRunning;
        preparing = newPreparing;
        timerSeconds = newTimerSeconds;
        glowSeconds = newGlowSeconds;
    }
}
