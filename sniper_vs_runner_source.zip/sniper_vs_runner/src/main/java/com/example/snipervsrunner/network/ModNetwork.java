package com.example.snipervsrunner.network;

import com.example.snipervsrunner.SniperVsRunnerMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    private static int packetId = 0;
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SniperVsRunnerMod.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    private ModNetwork() {}

    public static void register() {
        CHANNEL.messageBuilder(HudS2CPacket.class, packetId++)
                .encoder(HudS2CPacket::encode)
                .decoder(HudS2CPacket::decode)
                .consumerMainThread(HudS2CPacket::handle)
                .add();
    }

    public static void sendToPlayer(ServerPlayer player, HudS2CPacket packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
}
