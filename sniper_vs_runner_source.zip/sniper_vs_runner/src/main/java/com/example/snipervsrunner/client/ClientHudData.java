package com.example.snipervsrunner.client;

public final class ClientHudData {
    public static volatile boolean visible;
    public static volatile boolean preparation;
    public static volatile String sniper = "-";
    public static volatile String runner = "-";
    public static volatile int seconds;
    public static volatile int glowSeconds;

    private ClientHudData() {}

    public static void update(boolean show, boolean prep, String sniperName, String runnerName,
                              int time, int glowTime) {
        visible = show;
        preparation = prep;
        sniper = sniperName;
        runner = runnerName;
        seconds = time;
        glowSeconds = glowTime;
    }
}
