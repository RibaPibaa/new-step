package com.example.snipervsrunner.client;

import com.example.snipervsrunner.SniperVsRunnerMod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SniperVsRunnerMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HudOverlay {
    private HudOverlay() {}

    @SubscribeEvent
    public static void onRender(RenderGuiOverlayEvent.Post event) {
        if (!ClientHudData.visible) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.options.hideGui) return;

        var graphics = event.getGuiGraphics();
        var font = minecraft.font;

        String title = "SNIPER VS RUNNER";
        String sniperLine = "Sniper: " + ClientHudData.sniper;
        String runnerLine = "Runner: " + ClientHudData.runner;
        String timerLine = ClientHudData.preparation
                ? "Старт через: " + formatTime(ClientHudData.seconds)
                : "Время: " + formatTime(ClientHudData.seconds);
        String glowLine = ClientHudData.preparation
                ? "Раннер получил фору"
                : "Подсветка через: " + ClientHudData.glowSeconds + "с";

        int width = Math.max(Math.max(font.width(title), font.width(sniperLine)),
                Math.max(Math.max(font.width(runnerLine), font.width(timerLine)), font.width(glowLine))) + 16;
        int height = 62;
        int x = event.getWindow().getGuiScaledWidth() - width - 8;
        int y = 8;

        graphics.fill(x, y, x + width, y + height, 0xB9000000);
        graphics.fill(x, y, x + width, y + 2, 0xFFB3261E);
        graphics.drawString(font, Component.literal(title), x + 8, y + 6, 0xFFFF5555, false);
        graphics.drawString(font, Component.literal(sniperLine), x + 8, y + 18, 0xFFFFFFFF, false);
        graphics.drawString(font, Component.literal(runnerLine), x + 8, y + 29, 0xFFFFFFFF, false);
        graphics.drawString(font, Component.literal(timerLine), x + 8, y + 40, 0xFFFFFF55, false);
        graphics.drawString(font, Component.literal(glowLine), x + 8, y + 51, 0xFF55FFFF, false);
    }

    private static String formatTime(int seconds) {
        int safe = Math.max(0, seconds);
        return String.format("%02d:%02d", safe / 60, safe % 60);
    }
}
