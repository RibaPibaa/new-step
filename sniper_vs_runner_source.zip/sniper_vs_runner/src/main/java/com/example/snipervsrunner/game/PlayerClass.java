package com.example.snipervsrunner.game;

public enum PlayerClass {
    SNIPER,
    RUNNER
}
