package com.example.snipervsrunner.network;

import com.example.snipervsrunner.client.ClientHudData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class HudS2CPacket {
    private final boolean visible;
    private final boolean preparation;
    private final String sniper;
    private final String runner;
    private final int seconds;
    private final int glowSeconds;

    public HudS2CPacket(boolean visible, boolean preparation, String sniper, String runner, int seconds, int glowSeconds) {
        this.visible = visible;
        this.preparation = preparation;
        this.sniper = sniper;
        this.runner = runner;
        this.seconds = seconds;
        this.glowSeconds = glowSeconds;
    }

    public static void encode(HudS2CPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBoolean(packet.visible);
        buffer.writeBoolean(packet.preparation);
        buffer.writeUtf(packet.sniper, 64);
        buffer.writeUtf(packet.runner, 64);
        buffer.writeVarInt(packet.seconds);
        buffer.writeVarInt(packet.glowSeconds);
    }

    public static HudS2CPacket decode(FriendlyByteBuf buffer) {
        return new HudS2CPacket(
                buffer.readBoolean(),
                buffer.readBoolean(),
                buffer.readUtf(64),
                buffer.readUtf(64),
                buffer.readVarInt(),
                buffer.readVarInt()
        );
    }

    public static void handle(HudS2CPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHudData.update(packet.visible, packet.preparation,
                        packet.sniper, packet.runner, packet.seconds, packet.glowSeconds)));
        context.setPacketHandled(true);
    }
}
