package com.example.snipervsrunner;

import com.example.snipervsrunner.network.ModNetwork;
import net.minecraftforge.fml.common.Mod;

@Mod(SniperVsRunnerMod.MOD_ID)
public class SniperVsRunnerMod {
    public static final String MOD_ID = "snipervsrunner";

    public SniperVsRunnerMod() {
        ModNetwork.register();
    }
}
