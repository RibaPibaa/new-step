package com.example.snipervsrunner.game;

import com.example.snipervsrunner.network.HudS2CPacket;
import com.example.snipervsrunner.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = "snipervsrunner")
public final class GameManager {
    public enum Phase { IDLE, PREPARATION, RUNNING }

    private static final Map<UUID, PlayerClass> CLASSES = new HashMap<>();
    private static Phase phase = Phase.IDLE;
    private static UUID sniperId;
    private static UUID runnerId;
    private static String sniperName = "-";
    private static String runnerName = "-";
    private static int phaseTicks;
    private static int remainingTicks;
    private static int glowCooldown;
    private static int hudCooldown;
    private static int runnerWoolBaseline;

    private static double sniperX;
    private static double sniperY;
    private static double sniperZ;
    private static ResourceKey< net.minecraft.world.level.Level > sniperDimension;

    private GameManager() {}

    public static PlayerClass getClass(UUID id) {
        return CLASSES.get(id);
    }

    public static boolean assign(ServerPlayer player, PlayerClass playerClass) {
        if (phase != Phase.IDLE) return false;

        UUID existing = playerClass == PlayerClass.SNIPER ? sniperId : runnerId;
        if (existing != null && !existing.equals(player.getUUID())) return false;

        PlayerClass current = CLASSES.get(player.getUUID());
        if (current != null && current != playerClass) return false;

        CLASSES.put(player.getUUID(), playerClass);
        if (playerClass == PlayerClass.SNIPER) {
            sniperId = player.getUUID();
            sniperName = player.getGameProfile().getName();
        } else {
            runnerId = player.getUUID();
            runnerName = player.getGameProfile().getName();
        }
        return true;
    }

    public static boolean deleteClass(ServerPlayer player) {
        if (phase != Phase.IDLE) return false;
        PlayerClass removed = CLASSES.remove(player.getUUID());
        if (removed == null) return false;
        if (removed == PlayerClass.SNIPER) {
            sniperId = null;
            sniperName = "-";
        } else {
            runnerId = null;
            runnerName = "-";
        }
        return true;
    }

    public static String className(UUID id) {
        PlayerClass value = CLASSES.get(id);
        return value == null ? "none" : value.name().toLowerCase();
    }

    public static boolean start(MinecraftServer server) {
        if (phase != Phase.IDLE || sniperId == null || runnerId == null) return false;
        ServerPlayer sniper = server.getPlayerList().getPlayer(sniperId);
        ServerPlayer runner = server.getPlayerList().getPlayer(runnerId);
        if (sniper == null || runner == null || sniperId.equals(runnerId)) return false;

        phase = Phase.PREPARATION;
        phaseTicks = 200;
        remainingTicks = 0;
        glowCooldown = 600;
        hudCooldown = 0;

        sniperName = sniper.getGameProfile().getName();
        runnerName = runner.getGameProfile().getName();

        sniperX = sniper.getX();
        sniperY = sniper.getY();
        sniperZ = sniper.getZ();
        sniperDimension = sniper.level().dimension();

        runnerWoolBaseline = countRedWool(runner);
        sniper.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 220, 0, false, false, true));

        server.getPlayerList().broadcastSystemMessage(
                Component.literal("Sniper vs Runner: старт! У раннера есть 10 секунд форы.").withStyle(ChatFormatting.GOLD),
                false
        );
        sendHud(server);
        return true;
    }

    public static boolean stop(MinecraftServer server, String reason) {
        if (phase == Phase.IDLE) return false;
        finish(server, reason, null);
        return true;
    }

    private static void finish(MinecraftServer server, String message, UUID winnerId) {
        ServerPlayer sniper = sniperId == null ? null : server.getPlayerList().getPlayer(sniperId);
        ServerPlayer runner = runnerId == null ? null : server.getPlayerList().getPlayer(runnerId);

        if (sniper != null) {
            sniper.removeEffect(MobEffects.BLINDNESS);
            sniper.removeEffect(MobEffects.GLOWING);
        }
        if (runner != null) {
            runner.removeEffect(MobEffects.BLINDNESS);
            runner.removeEffect(MobEffects.GLOWING);
        }

        phase = Phase.IDLE;
        phaseTicks = 0;
        remainingTicks = 0;
        glowCooldown = 0;

        server.getPlayerList().broadcastSystemMessage(
                Component.literal(message).withStyle(ChatFormatting.YELLOW),
                false
        );
        sendHud(server);
    }

    private static void endRunnerWin(MinecraftServer server) {
        ServerPlayer sniper = sniperId == null ? null : server.getPlayerList().getPlayer(sniperId);
        if (sniper != null && sniper.isAlive()) {
            sniper.hurt(server.overworld().damageSources().generic(), Float.MAX_VALUE);
            if (sniper.isAlive()) sniper.kill();
        }
        finish(server, "РАННЕР ПОБЕДИЛ! Снайпер не успел его остановить.", runnerId);
    }

    private static void endSniperWin(MinecraftServer server, String reason) {
        finish(server, "СНАЙПЕР ПОБЕДИЛ! " + reason, sniperId);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || phase == Phase.IDLE) return;
        MinecraftServer server = event.getServer();
        ServerPlayer sniper = sniperId == null ? null : server.getPlayerList().getPlayer(sniperId);
        ServerPlayer runner = runnerId == null ? null : server.getPlayerList().getPlayer(runnerId);

        if (sniper == null) {
            if (runner != null) finish(server, "Матч остановлен: снайпер вышел с сервера.", null);
            else finish(server, "Матч остановлен: игроки вышли с сервера.", null);
            return;
        }
        if (runner == null) {
            endSniperWin(server, "Раннер вышел с сервера.");
            return;
        }

        // Снайпер остаётся на исходной точке, но может поворачивать камеру и стрелять.
        if (!sniper.level().dimension().equals(sniperDimension)
                || sniper.distanceToSqr(sniperX, sniperY, sniperZ) > 0.0001) {
            float yaw = sniper.getYRot();
            float pitch = sniper.getXRot();
            if (sniper.level() instanceof ServerLevel level && !level.dimension().equals(sniperDimension)) {
                ServerLevel targetLevel = server.getLevel(sniperDimension);
                if (targetLevel != null) sniper.teleportTo(targetLevel, sniperX, sniperY, sniperZ, yaw, pitch);
            } else {
                sniper.teleportTo(sniperX, sniperY, sniperZ);
                sniper.setYRot(yaw);
                sniper.setXRot(pitch);
            }
            sniper.setDeltaMovement(0, 0, 0);
            sniper.hurtMarked = true;
        }

        if (phase == Phase.PREPARATION) {
            phaseTicks--;
            if (phaseTicks <= 0) {
                sniper.removeEffect(MobEffects.BLINDNESS);
                phase = Phase.RUNNING;
                remainingTicks = 12000; // 10 минут
                glowCooldown = 600;     // первая подсветка через 30 секунд
                server.getPlayerList().broadcastSystemMessage(
                        Component.literal("Фора закончилась! Началась охота.").withStyle(ChatFormatting.RED),
                        false
                );
                sendHud(server);
            }
        } else if (phase == Phase.RUNNING) {
            if (countRedWool(runner) > 0) {
                endRunnerWin(server);
                return;
            }

            remainingTicks--;
            glowCooldown--;
            if (glowCooldown <= 0) {
                runner.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false, true));
                glowCooldown = 600;
            }
            if (remainingTicks <= 0) {
                endSniperWin(server, "Время раннера истекло.");
                return;
            }
        }

        hudCooldown++;
        if (hudCooldown >= 20) {
            hudCooldown = 0;
            sendHud(server);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (phase != Phase.RUNNING || runnerId == null) return;
        if (event.getEntity() instanceof ServerPlayer dead && dead.getUUID().equals(runnerId)) {
            MinecraftServer server = dead.getServer();
            if (server != null) endSniperWin(server, "Раннер был убит.");
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || phase == Phase.IDLE) return;
        MinecraftServer server = player.getServer();
        if (server == null) return;
        if (player.getUUID().equals(runnerId)) endSniperWin(server, "Раннер вышел с сервера.");
        else if (player.getUUID().equals(sniperId)) finish(server, "Матч остановлен: снайпер вышел с сервера.", null);
    }

    private static int countRedWool(ServerPlayer player) {
        int total = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(Items.RED_WOOL)) total += stack.getCount();
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (stack.is(Items.RED_WOOL)) total += stack.getCount();
        }
        return total;
    }

    private static void sendHud(MinecraftServer server) {
        int seconds = phase == Phase.PREPARATION
                ? (int) Math.ceil(phaseTicks / 20.0)
                : (int) Math.ceil(remainingTicks / 20.0);
        HudS2CPacket packet = new HudS2CPacket(
                phase != Phase.IDLE,
                phase == Phase.PREPARATION,
                sniperName,
                runnerName,
                seconds,
                phase == Phase.RUNNING ? (int) Math.ceil(glowCooldown / 20.0) : 0
        );
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ModNetwork.sendToPlayer(player, packet);
        }
    }
}
