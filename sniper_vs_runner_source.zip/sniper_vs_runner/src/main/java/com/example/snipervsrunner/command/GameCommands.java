package com.example.snipervsrunner.command;

import com.example.snipervsrunner.game.GameManager;
import com.example.snipervsrunner.game.PlayerClass;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "snipervsrunner")
public final class GameCommands {
    private GameCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        var dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("sniper")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> assign(ctx.getSource().getPlayerOrException(),
                                EntityArgument.getPlayer(ctx, "player"), PlayerClass.SNIPER))));

        dispatcher.register(Commands.literal("runner")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> assign(ctx.getSource().getPlayerOrException(),
                                EntityArgument.getPlayer(ctx, "player"), PlayerClass.RUNNER))));

        dispatcher.register(Commands.literal("classdelete")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            boolean success = GameManager.deleteClass(target);
                            ctx.getSource().sendSuccess(() -> Component.literal(success
                                    ? "Класс игрока " + target.getGameProfile().getName() + " удалён."
                                    : "Не удалось удалить класс. Возможно, матч уже идёт или класс не назначен."), true);
                            return success ? 1 : 0;
                        })));

        dispatcher.register(Commands.literal("startgame")
                .requires(source -> source.hasPermission(2))
                .executes(ctx -> {
                    boolean success = GameManager.start(ctx.getSource().getServer());
                    ctx.getSource().sendSuccess(() -> Component.literal(success
                            ? "Sniper vs Runner запущен."
                            : "Нужны два разных игрока: один Sniper и один Runner. Матч уже может идти."), true);
                    return success ? 1 : 0;
                }));

        dispatcher.register(Commands.literal("stopgame")
                .requires(source -> source.hasPermission(2))
                .executes(ctx -> {
                    boolean success = GameManager.stop(ctx.getSource().getServer(), "Матч остановлен командой /stopgame.");
                    ctx.getSource().sendSuccess(() -> Component.literal(success
                            ? "Матч остановлен."
                            : "Сейчас матч не запущен."), true);
                    return success ? 1 : 0;
                }));
    }

    private static int assign(ServerPlayer source, ServerPlayer target, PlayerClass playerClass) {
        boolean success = GameManager.assign(target, playerClass);
        String className = playerClass == PlayerClass.SNIPER ? "снайпер" : "раннер";
        source.sendSuccess(() -> Component.literal(success
                ? target.getGameProfile().getName() + " назначен: " + className + "."
                : "Не удалось назначить класс: он уже занят, игрок имеет другой класс или матч уже идёт."), true);
        return success ? 1 : 0;
    }
}
