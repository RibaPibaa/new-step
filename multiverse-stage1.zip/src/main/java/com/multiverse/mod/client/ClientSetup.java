package com.multiverse.mod.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.multiverse.mod.MultiverseMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;

/** Client-only setup: keybinds, the suit render layer, and the HUD overlay. */
public final class ClientSetup {
    public static final String CATEGORY = "key.categories.multiverse";

    public static final KeyMapping LASER = new KeyMapping("key.multiverse.laser",
            InputConstants.Type.KEYSYM, InputConstants.getKey("key.keyboard.z").getValue(), CATEGORY);
    public static final KeyMapping CLAP = new KeyMapping("key.multiverse.clap",
            InputConstants.Type.KEYSYM, InputConstants.getKey("key.keyboard.x").getValue(), CATEGORY);
    public static final KeyMapping LAUNCH = new KeyMapping("key.multiverse.launch",
            InputConstants.Type.KEYSYM, InputConstants.getKey("key.keyboard.c").getValue(), CATEGORY);
    public static final KeyMapping GRAB = new KeyMapping("key.multiverse.grab",
            InputConstants.Type.KEYSYM, InputConstants.getKey("key.keyboard.r").getValue(), CATEGORY);
    /** Reserved for the helmet toggle (Soldier Boy). Unused by Homelander. */
    public static final KeyMapping HELMET = new KeyMapping("key.multiverse.helmet",
            InputConstants.Type.KEYSYM, InputConstants.getKey("key.keyboard.y").getValue(), CATEGORY);

    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerKeys);
        modBus.addListener(ClientSetup::registerLayers);
        modBus.addListener(ClientSetup::registerOverlays);
        MinecraftForge.EVENT_BUS.register(new ClientForgeEvents());
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(LASER);
        event.register(CLAP);
        event.register(LAUNCH);
        event.register(GRAB);
        event.register(HELMET);
    }

    private static void registerLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                renderer.addLayer(new SuitLayer(renderer));
            }
        }
    }

    private static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll(MultiverseMod.MOD_ID + "_abilities", AbilityHud::render);
    }
}
