package com.multiverse.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.multiverse.mod.Heroes;
import com.multiverse.mod.MultiverseEffects;
import com.multiverse.mod.MultiverseMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Draws the parts of the suit that vanilla armor can't: the massive right shoulder pauldron,
 * the glowing eyes and the cloth cape. Positions are in body/head/arm space, which is what
 * the player model uses.
 */
public final class SuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation CAPE_TEXTURE =
            new ResourceLocation(MultiverseMod.MOD_ID, "textures/entity/homelander_cape.png");
    private static final ResourceLocation WHITE =
            new ResourceLocation(MultiverseMod.MOD_ID, "textures/misc/white.png");
    private static final float PX = 1.0F / 16.0F;

    private static final Map<UUID, ClothSim> SIMS = new HashMap<>();

    public SuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static void clear(UUID id) {
        SIMS.remove(id);
    }

    @Override
    public void render(PoseStack stack, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!Heroes.isWearingHomelander(player)) return;
        PlayerModel<AbstractClientPlayer> model = getParentModel();

        // Right shoulder pauldron: one big gold eagle-style piece.
        stack.pushPose();
        model.rightArm.translateAndRotate(stack);
        VertexConsumer solid = buffers.getBuffer(RenderType.entitySolid(WHITE));
        drawBox(stack.last(), solid, -4.5F, -5.5F, -3.5F, 2.5F, 0.5F, 3.5F,
                1.0F, 0.78F, 0.25F, 1.0F, light);
        stack.popPose();

        // Eyes: blue at rest, fading to red while charging the laser or during Burnout.
        stack.pushPose();
        model.head.translateAndRotate(stack);
        float charge = player == Minecraft.getInstance().player ? ClientState.laserCharge() : 0F;
        if (player.hasEffect(MultiverseEffects.BURNOUT.get())) charge = 1F;
        float r = lerp(0.25F, 1.0F, charge);
        float g = lerp(0.6F, 0.1F, charge);
        float b = lerp(1.0F, 0.1F, charge);
        VertexConsumer glow = buffers.getBuffer(RenderType.entityTranslucentEmissive(WHITE));
        int full = LightTexture.FULL_BRIGHT;
        drawBox(stack.last(), glow, -3.0F, -5.0F, -4.15F, -1.0F, -3.0F, -4.05F, r, g, b, 1.0F, full);
        drawBox(stack.last(), glow, 1.0F, -5.0F, -4.15F, 3.0F, -3.0F, -4.05F, r, g, b, 1.0F, full);
        stack.popPose();

        // Cape: cloth simulation anchored at the shoulders, hanging from the body.
        stack.pushPose();
        model.body.translateAndRotate(stack);
        ClothSim sim = SIMS.computeIfAbsent(player.getUUID(), k -> new ClothSim());
        Vec3 vel = player.getDeltaMovement();
        Vec3 wind = vel.scale(-16.0 * 0.35);
        sim.step(wind, new Vec3(-5.0, 2.0, 2.6), new Vec3(5.0, 2.0, 2.6));
        drawCape(stack.last(), buffers.getBuffer(RenderType.entityCutoutNoCull(CAPE_TEXTURE)), sim, light);
        stack.popPose();
    }

    private static void drawCape(PoseStack.Pose pose, VertexConsumer vc, ClothSim sim, int light) {
        for (int r = 0; r < ClothSim.ROWS - 1; r++) {
            for (int c = 0; c < ClothSim.COLS - 1; c++) {
                float u0 = c / (float) (ClothSim.COLS - 1);
                float u1 = (c + 1) / (float) (ClothSim.COLS - 1);
                float v0 = r / (float) (ClothSim.ROWS - 1);
                float v1 = (r + 1) / (float) (ClothSim.ROWS - 1);
                Vec3 p00 = sim.get(r, c);
                Vec3 p01 = sim.get(r, c + 1);
                Vec3 p11 = sim.get(r + 1, c + 1);
                Vec3 p10 = sim.get(r + 1, c);
                float[] xyz = {
                        (float) p00.x, (float) p00.y, (float) p00.z,
                        (float) p01.x, (float) p01.y, (float) p01.z,
                        (float) p11.x, (float) p11.y, (float) p11.z,
                        (float) p10.x, (float) p10.y, (float) p10.z};
                float[] uv = {u0, v0, u1, v0, u1, v1, u0, v1};
                quad(pose, vc, xyz, uv, 0, 0, 1, 1, 1, 1, 1, light);
            }
        }
    }

    /** Axis-aligned box in pixel units, tinted with a color and textured with the white texture. */
    private static void drawBox(PoseStack.Pose pose, VertexConsumer vc,
                                float x1, float y1, float z1, float x2, float y2, float z2,
                                float r, float g, float b, float a, int light) {
        float[] uv = {0, 0, 1, 0, 1, 1, 0, 1};
        // +Z (front in model space)
        quad(pose, vc, new float[]{x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2}, uv, 0, 0, 1, r, g, b, a, light);
        // -Z
        quad(pose, vc, new float[]{x2, y1, z1, x1, y1, z1, x1, y2, z1, x2, y2, z1}, uv, 0, 0, -1, r, g, b, a, light);
        // +X
        quad(pose, vc, new float[]{x2, y1, z2, x2, y1, z1, x2, y2, z1, x2, y2, z2}, uv, 1, 0, 0, r, g, b, a, light);
        // -X
        quad(pose, vc, new float[]{x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1}, uv, -1, 0, 0, r, g, b, a, light);
        // +Y
        quad(pose, vc, new float[]{x1, y2, z2, x2, y2, z2, x2, y2, z1, x1, y2, z1}, uv, 0, 1, 0, r, g, b, a, light);
        // -Y
        quad(pose, vc, new float[]{x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2}, uv, 0, -1, 0, r, g, b, a, light);
    }

    private static void quad(PoseStack.Pose pose, VertexConsumer vc, float[] xyz, float[] uv,
                             float nx, float ny, float nz, float r, float g, float b, float a, int light) {
        for (int i = 0; i < 4; i++) {
            vc.vertex(pose.pose(), xyz[i * 3] * PX, xyz[i * 3 + 1] * PX, xyz[i * 3 + 2] * PX)
                    .color(r, g, b, a)
                    .uv(uv[i * 2], uv[i * 2 + 1])
                    .overlayCoords(OverlayTexture.NO_OVERLAY)
                    .uv2(light)
                    .normal(pose.normal(), nx, ny, nz)
                    .endVertex();
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
