package com.multiverse.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.multiverse.mod.Heroes;
import com.multiverse.mod.MultiverseEffects;
import com.multiverse.mod.Net;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Client ticking: key edges to the server, double-jump detection, flight lean. */
public class ClientForgeEvents {
    private static final KeyMapping[] ABILITY_KEYS = {
            ClientSetup.LASER, ClientSetup.CLAP, ClientSetup.LAUNCH, ClientSetup.GRAB
    };
    private static final long[] COOLDOWN_MS = {1000L, 20_000L, 30_000L, 20_000L};

    private final boolean[] prevDown = new boolean[ABILITY_KEYS.length];
    private boolean prevJump;
    private int jumpsUsed;
    private final Map<UUID, Float> leanByPlayer = new HashMap<>();

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) return;

        boolean suit = Heroes.isWearingHomelander(player);

        // Ability keys: send press and release edges, and start local cooldown estimates.
        for (int i = 0; i < ABILITY_KEYS.length; i++) {
            boolean down = ABILITY_KEYS[i].isDown();
            if (down == prevDown[i]) continue;
            prevDown[i] = down;
            if (!suit) continue;
            Net.CHANNEL.sendToServer(new Net.AbilityPacket(i, down));
            if (i == 0) {
                ClientState.laserHeld = down;
                if (!down) ClientState.startCooldown(0, COOLDOWN_MS[0]);
            } else if (down) {
                ClientState.startCooldown(i, COOLDOWN_MS[i]);
            }
        }

        // Laser charge: builds over one second while held, decays when released.
        if (ClientState.laserHeld) {
            ClientState.laserTicks++;
        } else if (ClientState.laserTicks > 0) {
            ClientState.laserTicks = Math.max(0, ClientState.laserTicks - 2);
        }

        // Double jump: the first ground jump counts as 1, a second press in the air toggles flight.
        boolean jump = mc.options.keyJump.isDown();
        if (player.onGround()) jumpsUsed = 0;
        if (jump && !prevJump) {
            if (player.onGround()) {
                jumpsUsed = 1;
            } else if (jumpsUsed == 1 && suit) {
                jumpsUsed = 2;
                Net.CHANNEL.sendToServer(new Net.AbilityPacket(4, true));
            }
        }
        prevJump = jump;
    }

    /** Typing letters while grabbed. The server validates every letter. */
    @SubscribeEvent
    public void onKey(InputEvent.Key event) {
        if (event.getAction() != GLFW.GLFW_PRESS || ClientState.prompt.isEmpty()) return;
        char letter = switch (event.getKey()) {
            case GLFW.GLFW_KEY_W -> 'W';
            case GLFW.GLFW_KEY_A -> 'A';
            case GLFW.GLFW_KEY_S -> 'S';
            case GLFW.GLFW_KEY_D -> 'D';
            case GLFW.GLFW_KEY_E -> 'E';
            case GLFW.GLFW_KEY_R -> 'R';
            default -> 0;
        };
        if (letter == 0) return;
        // Mirror the server: a correct letter advances, a wrong one resets.
        if (ClientState.escapeIndex < ClientState.prompt.length()
                && letter == ClientState.prompt.charAt(ClientState.escapeIndex)) {
            ClientState.escapeIndex++;
        } else {
            ClientState.escapeIndex = 0;
        }
        Net.CHANNEL.sendToServer(new Net.EscapePacket(letter));
    }

    /** Body lean for flight speeds, plus a Burnout kneel lean. Tune LEAN_SIGN if the lean goes the wrong way. */
    @SubscribeEvent
    public void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        if (!Heroes.isWearingHomelander(p)) return;

        double speed = p.getDeltaMovement().length();
        boolean flying = p.getAbilities().flying;

        float target = 0F;
        if (p.hasEffect(MultiverseEffects.BURNOUT.get())) {
            target = 55F;
        } else if (flying) {
            target = speed < 0.06 ? 0F : (speed < 0.2 ? 25F : 65F);
        }

        float current = leanByPlayer.getOrDefault(p.getUUID(), 0F);
        current += (target - current) * 0.15F;
        leanByPlayer.put(p.getUUID(), current);

        PoseStack stack = event.getPoseStack();
        if (Math.abs(current) > 0.1F) {
            final float LEAN_SIGN = 1F; // flip to -1 if the lean looks backwards in-game
            stack.translate(0, 0.9, 0);
            stack.mulPose(Axis.XP.rotationDegrees(LEAN_SIGN * current));
            stack.translate(0, -0.9, 0);
        }
        if (flying && speed < 0.06) {
            double bob = Math.sin((p.tickCount + event.getPartialTick()) * 0.12) * 0.03;
            stack.translate(0, bob, 0);
        }
    }

    public static void forget(UUID id) {
        SuitLayer.clear(id);
    }
}
