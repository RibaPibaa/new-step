package com.multiverse.mod.client;

/** Client-only mirror of what the HUD and renderers need. Server state stays authoritative. */
public final class ClientState {
    /** Local cooldown estimate per slot (ms timestamp when ready). Server rules always win. */
    public static final long[] READY_AT_MS = new long[4];

    public static boolean laserHeld;
    public static int laserTicks;

    /** Letters to type while grabbed, empty when not grabbed. */
    public static String prompt = "";
    public static int escapeIndex;

    private ClientState() {}

    public static void onGrabPrompt(String letters) {
        prompt = letters;
        escapeIndex = 0;
    }

    public static float laserCharge() {
        return Math.min(1.0F, laserTicks / 20.0F);
    }

    public static void startCooldown(int slot, long ms) {
        READY_AT_MS[slot] = System.currentTimeMillis() + ms;
    }

    public static long remainingMs(int slot) {
        return Math.max(0L, READY_AT_MS[slot] - System.currentTimeMillis());
    }
}
