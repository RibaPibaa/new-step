package com.multiverse.mod.client;

import com.multiverse.mod.Heroes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Ability list in the bottom-right corner, plus the grab letter prompt in the centre. */
public final class AbilityHud {
    private static final String[] NAMES = {"Laser Vision", "Clap", "Launch", "Grab"};
    private static final String[] KEYS = {"Z", "X", "C", "R"};

    private AbilityHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !Heroes.isWearingHomelander(mc.player)) return;
        Font font = mc.font;

        int boxWidth = 130;
        int rowHeight = 14;
        int x = width - boxWidth - 6;
        int y = height - 8 - NAMES.length * rowHeight;

        for (int i = 0; i < NAMES.length; i++) {
            int rowY = y + i * rowHeight;
            long remaining = ClientState.remainingMs(i);
            String status = remaining > 0 ? String.format("%.1fs", remaining / 1000.0F) : "READY";
            int statusColor = remaining > 0 ? 0xFFFF8080 : 0xFF80FF80;

            g.fill(x, rowY, width - 6, rowY + rowHeight - 2, 0x80000000);
            g.drawString(font, "[" + KEYS[i] + "] " + NAMES[i], x + 4, rowY + 2, 0xFFFFFFFF, false);
            g.drawString(font, status, width - 6 - 4 - font.width(status), rowY + 2, statusColor, false);
        }

        if (!ClientState.prompt.isEmpty()) {
            renderPrompt(g, font, width, height);
        }
    }

    private static void renderPrompt(GuiGraphics g, Font font, int width, int height) {
        String letters = ClientState.prompt;
        int spacing = 18;
        int totalWidth = letters.length() * spacing;
        int startX = width / 2 - totalWidth / 2;
        int y = height / 2 + 30;

        g.drawString(font, "Break free: type the letters in order", width / 2 - 110, y - 14, 0xFFFFFFFF, true);
        for (int i = 0; i < letters.length(); i++) {
            int color = i < ClientState.escapeIndex ? 0xFF60FF60 : 0xFFFFFFFF;
            g.fill(startX + i * spacing - 2, y - 2, startX + i * spacing + 14, y + 12, 0xA0000000);
            g.drawString(font, String.valueOf(letters.charAt(i)), startX + i * spacing + 2, y + 1, color, false);
        }
    }
}
