package com.multiverse.mod.client;

import net.minecraft.world.phys.Vec3;

/**
 * Verlet cloth for the cape. Row 0 is pinned to the shoulders. Each other point keeps its
 * previous position, adds gravity and wind, then is pulled back toward its neighbours.
 * Units are model pixels (1/16 of a block).
 */
public final class ClothSim {
    public static final int COLS = 5;
    public static final int ROWS = 8;

    private static final double REST = 2.6;
    private static final double GRAVITY = 0.09;
    private static final double DAMPING = 0.97;
    private static final int ITERATIONS = 4;

    private final Vec3[][] pos = new Vec3[ROWS][COLS];
    private final Vec3[][] prev = new Vec3[ROWS][COLS];
    private boolean initialized;

    public Vec3 get(int row, int col) {
        return pos[row][col];
    }

    /** Advances one frame. wind is in pixels per tick. */
    public void step(Vec3 wind, Vec3 leftAnchor, Vec3 rightAnchor) {
        if (!initialized) {
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    Vec3 start = anchorAt(leftAnchor, rightAnchor, c).add(0, r * REST, 0);
                    pos[r][c] = start;
                    prev[r][c] = start;
                }
            }
            initialized = true;
        }

        for (int c = 0; c < COLS; c++) {
            Vec3 a = anchorAt(leftAnchor, rightAnchor, c);
            pos[0][c] = a;
            prev[0][c] = a;
        }

        for (int r = 1; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                Vec3 p = pos[r][c];
                Vec3 velocity = p.subtract(prev[r][c]).scale(DAMPING);
                prev[r][c] = p;
                pos[r][c] = p.add(velocity)
                        .add(0, GRAVITY, 0)
                        .add(wind.scale(0.02));
            }
        }

        for (int it = 0; it < ITERATIONS; it++) {
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (c + 1 < COLS) satisfy(r, c, r, c + 1);
                    if (r + 1 < ROWS) satisfy(r, c, r + 1, c);
                }
            }
            for (int c = 0; c < COLS; c++) pos[0][c] = anchorAt(leftAnchor, rightAnchor, c);
        }
    }

    private static Vec3 anchorAt(Vec3 left, Vec3 right, int col) {
        double t = col / (double) (COLS - 1);
        return new Vec3(
                left.x + (right.x - left.x) * t,
                left.y + (right.y - left.y) * t,
                left.z + (right.z - left.z) * t);
    }

    private void satisfy(int r1, int c1, int r2, int c2) {
        Vec3 a = pos[r1][c1];
        Vec3 b = pos[r2][c2];
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 1.0E-6) return;
        double diff = (len - REST) / len;
        boolean aPinned = r1 == 0;
        boolean bPinned = r2 == 0;
        if (aPinned && bPinned) return;
        if (aPinned) {
            pos[r2][c2] = b.subtract(d.scale(diff));
        } else if (bPinned) {
            pos[r1][c1] = a.add(d.scale(diff));
        } else {
            pos[r1][c1] = a.add(d.scale(diff * 0.5));
            pos[r2][c2] = b.subtract(d.scale(diff * 0.5));
        }
    }
}
